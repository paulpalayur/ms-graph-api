import requests
from msal import ConfidentialClientApplication

class GraphService:
    def __init__(self, client_id:str, client_credential:str, tenant_id:str, authority:str, scope:list[str]) -> None:
        self._client_id = client_id
        self._client_credential = client_credential
        self._tenant_id = tenant_id
        self._authority = authority
        self._scope = scope
        self._client_token = self._get_client_token()

    def _get_client_token(self) -> str:
        client = ConfidentialClientApplication(
            client_id=self._client_id,
            client_credential=self._client_credential,
            authority=self._authority
        )
        result = None

        # Firstly, looks up a token from cache
        # Since we are looking for token for the current app, NOT for an end user,
        # notice we give account parameter as None.
        result = client.acquire_token_silent(self._scope, account=None)
        print(result)

        result = client.acquire_token_for_client(self._scope)
        if "access_token" in result:
            print("Access token generated")
            return result.get("access_token")
        else:            
            print(result.get("error"))
            print(result.get("error_description"))
            print(result.get("correlation_id"))
            return None

    def get_site(self, site_name:str, host_name:str):
        url = f"https://graph.microsoft.com/v1.0/sites/{host_name}:/sites/{site_name}"        
        site = self._request_graph_service(url)        
        return site

    def get_document_libraries(self, site_id:str):
        url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drives"
        document_libraries = self._request_graph_service(url)
        return document_libraries

    def get_files(self, site_id, drive_id,file_name_starts_with:tuple=None):        
        url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drives/{drive_id}/root/children"

        if file_name_starts_with:
            key,value = file_name_starts_with
            if key and value:
                url = url + f"?$filter=startsWith({key},'{value}')"
            else:
                raise ValueError("Both key and value should exist for file_name_starts_with tuple")

        drive_files = self._request_graph_service(url)        
        return drive_files
    
    def _request_graph_service(self,url):
        return requests.get(url, headers={'Authorization': 'Bearer ' + self._client_token}, ).json()