
Import-Module "$PSScriptRoot\graphservice.psm1"
$tenant_id = "8579dec8-7b18-4898-9e77-e3cd592a713a"
#$token_endpoint = "https://login.microsoftonline.com/${tenant_id}/oauth2/v2.0/token"

# $body=@{
#     client_id = "9f094f57-af8a-4431-880e-182a6160d50a"
#     tenant_id = "8579dec8-7b18-4898-9e77-e3cd592a713a"
#     client_secret = "dSP7Q~EA6bfi5rk-tczXJYkjAFyjteV8O5sDS"
#     grant_type = "client_credentials"
#     scope = "https://graph.microsoft.com/.default"
# }

$client_id = "9f094f57-af8a-4431-880e-182a6160d50a"
$tenant_id = "8579dec8-7b18-4898-9e77-e3cd592a713a"
$client_secret = "dSP7Q~EA6bfi5rk-tczXJYkjAFyjteV8O5sDS"
$grant_type = "client_credentials"
$scope = "https://graph.microsoft.com/.default"

# $access_token = Invoke-RestMethod -Method Post -Uri $token_endpoint -Body $body
# $access_token

# function Get-AccessToken {
#     [CmdletBinding()]
#     param (
#         [Parameter(Mandatory=$true)]
#         [String]
#         $client_id,

#         [Parameter(Mandatory=$true)]
#         [String]
#         $tenant_id,

#         [Parameter(Mandatory=$true)]
#         [String]
#         $client_secret,

#         [Parameter(Mandatory=$true)]
#         [String]
#         $grant_type,

#         [Parameter(Mandatory=$true)]
#         [String]
#         $scope
#     )
    
#     begin {
#         $body=@{
#             client_id = $client_id
#             tenant_id = $tenant_id
#             client_secret = $client_secret
#             grant_type = $grant_type
#             scope = $scope
#         }
#         $token_endpoint = "https://login.microsoftonline.com/${tenant_id}/oauth2/v2.0/token"
#     }
    
#     process {
#         Invoke-RestMethod -Method Post -Uri $token_endpoint -Body $body
#     }
# }

# function Get-Site {
#     [CmdletBinding()]
#     param (
#         [Parameter(Mandatory=$true)]
#         [String]
#         $site_name,

#         [Parameter(Mandatory=$true)]
#         [String]
#         $host_name,

#         [Parameter(Mandatory=$true)]
#         [String]
#         $access_token
#     )
    
#     begin {
#         $uri = "https://graph.microsoft.com/v1.0/sites/${host_name}:/sites/${site_name}"
#     }
    
#     process {
#         Invoke-RestMethod -Method Get -Uri $uri -Headers @{Authorization = "Bearer $($access_token)"}
#     }    
# }

# function Get-DocumentLibraries {
#     [CmdletBinding()]
#     param (
#         [Parameter(Mandatory=$true)]
#         [String]
#         $site_id,

#         [Parameter(Mandatory=$true)]
#         [String]
#         $access_token
#     )
    
#     begin {
#         $uri = "https://graph.microsoft.com/v1.0/sites/${site_id}/drives"
#     }
    
#     process {
#         Invoke-RestMethod -Method Get -Uri $uri -Headers @{Authorization = "Bearer $($access_token)"}
#     }
# }

# function Get-Files {
#     [CmdletBinding()]
#     param (
#         [Parameter(Mandatory=$true)]
#         [String]
#         $site_id,

#         [Parameter(Mandatory=$true)]
#         [String]
#         $drive_id,

#         [Parameter(Mandatory=$true)]
#         [String]
#         $access_token
        
#     )
    
#     begin {
#         $uri = "https://graph.microsoft.com/v1.0/sites/${site_id}/drives/${drive_id}/root/children"
#     }
    
#     process {
#         Invoke-RestMethod -Method Get -Uri $uri -Headers @{Authorization = "Bearer $($access_token)"}        
#     }
# }

# function Get-File {
#     [CmdletBinding()]
#     param (
#         [Parameter(Mandatory=$true)]
#         [String]
#         $download_url,

#         [Parameter(Mandatory=$true)]
#         [String]
#         $output_file_path
#     )
#     process {
#         Invoke-WebRequest -Uri $download_url -OutFile "$output_file_path"
#     }
# }

$access_token = Get-AccessToken -client_id $client_id -client_secret $client_secret -tenant_id $tenant_id -grant_type $grant_type -scope $scope
#$access_token.access_token
$host_name = "1wb67j.sharepoint.com"
$site = Get-Site -site_name "test" -host_name $host_name -access_token $access_token.access_token
$site.id

$libraries = Get-DocumentLibraries -site_id $site.id -access_token $access_token.access_token
$libraries
$libraries.value.id

$files = Get-Files -site_id $site.id -drive_id $libraries.value.id -access_token $access_token.access_token
"files are"
$files.value|select name,id,"@microsoft.graph.downloadUrl",createdDateTime,lastModifiedDateTime,createdBy,file|ft

$files.value[0].'@microsoft.graph.downloadUrl'
Get-File -download_url $files.value[3].'@microsoft.graph.downloadUrl' -output_file_path "$($PSScriptRoot)\$($files.value[3].name)"
