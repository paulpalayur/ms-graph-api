import requests

url = "https://login.microsoftonline.com/8579dec8-7b18-4898-9e77-e3cd592a713a/oauth2/v2.0/token"

payload='scope=https%3A%2F%2Fgraph.microsoft.com%2F.default&client_id=0bc7887f-335c-4474-8a45-5eac1f6c428d&client_secret=WYu7Q~gCf6yV.yV1XjddkxzzH6bgjrFMb6aIN&grant_type=client_credentials'
headers = {
  'Content-Type': 'application/x-www-form-urlencoded',
  'Cookie': 'fpc=AuOpLMMLllFOsK_vX-4k-SGLJIvHAQAAADVkltkOAAAA; stsservicecookie=estsfd; x-ms-gateway-slice=estsfd'
}

response = requests.request("GET", url, headers=headers, data=payload)

print(response.text)