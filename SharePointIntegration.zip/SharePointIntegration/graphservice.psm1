function Get-AccessToken {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [String]
        $client_id,

        [Parameter(Mandatory=$true)]
        [String]
        $tenant_id,

        [Parameter(Mandatory=$true)]
        [String]
        $client_secret,

        [Parameter(Mandatory=$true)]
        [String]
        $grant_type,

        [Parameter(Mandatory=$true)]
        [String]
        $scope
    )
    
    begin {
        $body=@{
            client_id = $client_id
            tenant_id = $tenant_id
            client_secret = $client_secret
            grant_type = $grant_type
            scope = $scope
        }
        $token_endpoint = "https://login.microsoftonline.com/${tenant_id}/oauth2/v2.0/token"
    }
    
    process {
        Invoke-RestMethod -Method Post -Uri $token_endpoint -Body $body
    }
}

function Get-Site {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [String]
        $site_name,

        [Parameter(Mandatory=$true)]
        [String]
        $host_name,

        [Parameter(Mandatory=$true)]
        [String]
        $access_token
    )
    
    begin {
        $uri = "https://graph.microsoft.com/v1.0/sites/${host_name}:/sites/${site_name}"
    }
    
    process {
        Invoke-RestMethod -Method Get -Uri $uri -Headers @{Authorization = "Bearer $($access_token)"}
    }    
}

function Get-DocumentLibraries {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [String]
        $site_id,

        [Parameter(Mandatory=$true)]
        [String]
        $access_token
    )
    
    begin {
        $uri = "https://graph.microsoft.com/v1.0/sites/${site_id}/drives"
    }
    
    process {
        Invoke-RestMethod -Method Get -Uri $uri -Headers @{Authorization = "Bearer $($access_token)"}
    }
}

function Get-Files {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [String]
        $site_id,

        [Parameter(Mandatory=$true)]
        [String]
        $drive_id,

        [Parameter(Mandatory=$true)]
        [String]
        $access_token
        
    )
    
    begin {
        $uri = "https://graph.microsoft.com/v1.0/sites/${site_id}/drives/${drive_id}/root/children"
    }
    
    process {
        Invoke-RestMethod -Method Get -Uri $uri -Headers @{Authorization = "Bearer $($access_token)"}        
    }
}

function Get-File {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [String]
        $download_url,

        [Parameter(Mandatory=$true)]
        [String]
        $output_file_path
    )
    process {
        Invoke-WebRequest -Uri $download_url -OutFile "$output_file_path"
    }
}

Export-ModuleMember -Function *