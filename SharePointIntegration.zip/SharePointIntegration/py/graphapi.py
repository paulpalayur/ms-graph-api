import configparser
from socket import MsgFlag
from msal import ConfidentialClientApplication
import requests

CLIENT_ID = "9f094f57-af8a-4431-880e-182a6160d50a"
SECRET_VALUE = "dSP7Q~EA6bfi5rk-tczXJYkjAFyjteV8O5sDS"
TENANT_ID = "8579dec8-7b18-4898-9e77-e3cd592a713a"
#GRANT_TYPE = "client_credentials"
#SCOPE = ["https://graph.microsoft.com/.default"]
AUTHORITY_URL = f"https://login.microsoftonline.com/{TENANT_ID}"
#BASE_URL = "https://graph.microsoft.com/v1.0/"

#endpoint = BASE_URL
#SCOPES = ['User.Read', 'Sites.Selected']
scope = ["https://graph.microsoft.com/.default"]
print(AUTHORITY_URL)
client_instance = ConfidentialClientApplication(
    client_id=CLIENT_ID,
    client_credential=SECRET_VALUE,
    authority=AUTHORITY_URL
)

result = None
result = client_instance.acquire_token_silent(scope,account=None)
print(result)

result = client_instance.acquire_token_for_client(scope)
print(result)
if 'access_token' in result:
    host_name = "1wb67j.sharepoint.com"
    site_name = "test"
    site_url = f"https://graph.microsoft.com/v1.0/sites/{host_name}:/sites/{site_name}"

    graph_data = requests.get(  # Use token to call downstream service
        site_url,
        headers={'Authorization': 'Bearer ' + result['access_token']}, ).json()
    print(graph_data)