from email import header
from pydoc import doc
from graphservice import GraphService
from tabulate import tabulate


CLIENT_ID = "9f094f57-af8a-4431-880e-182a6160d50a"
SECRET_VALUE = "dSP7Q~EA6bfi5rk-tczXJYkjAFyjteV8O5sDS"
TENANT_ID = "8579dec8-7b18-4898-9e77-e3cd592a713a"
AUTHORITY_URL = f"https://login.microsoftonline.com/{TENANT_ID}"
scope = ["https://graph.microsoft.com/.default"]
HOST_NAME = "1wb67j.sharepoint.com"
SITE_NAME = "test"


gs = GraphService(CLIENT_ID, SECRET_VALUE,TENANT_ID, AUTHORITY_URL, scope)
site = gs.get_site(SITE_NAME, HOST_NAME)
print("site id is")
print(site.get("id"))
doc_lib = gs.get_document_libraries(site.get("id"))
print("doc lib id is")
doc_lib_id = doc_lib.get("value")[0]["id"]
print(doc_lib_id)
print("files are")
files_result = gs.get_files(site.get("id"),doc_lib_id)
files = files_result.get("value")
#print(files)
file_list:list = []
for file in files:
    lst=[]
    name=file['name']
    id=file['id']
    download_url = file['@microsoft.graph.downloadUrl']
    lst.append(name)
    lst.append(id)
    lst.append(download_url)
    file_list.append(lst)
    # print(f"name {file['name']}")
    # print(f"id {file['id']}")
    # print(f"download file url {file['@microsoft.graph.downloadUrl']}")
print(file_list)    
print(tabulate(file_list,headers=["Name","id","download_url"]))
    



